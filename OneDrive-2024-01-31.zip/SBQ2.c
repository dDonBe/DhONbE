#include <stdio.h>
#include<conio.h>

#define SINGLE_LIMIT 6000
#define SINGLE_RATE1 0.1
#define SINGLE_RATE2 0.15
#define SINGLE_RATE3 0.27
#define SINGLE_RATE4 0.3

#define SEPARATE_LIMIT 24000
#define SEPARATE_RATE1 0.1
#define SEPARATE_RATE2 0.15
#define SEPARATE_RATE3 0.27
#define SEPARATE_RATE4 0.3

#define JOINT_LIMIT 12000
#define JOINT_RATE1 0.1
#define JOINT_RATE2 0.15
#define JOINT_RATE3 0.27
#define JOINT_RATE4 0.3




int main() {
    int filingStatus;
    double taxableIncome, taxAmount;

    printf("\n\n\t\tWelcome to the Personal Income Tax Calculator!\n");

    printf("\n\tFiling Status:\n");
    printf("\t\t0- Single Filer\n");
    printf("\t\t1- Married Filing Jointly\n");
    printf("\t\t2- Married Filing Separately\n");
    printf("\n\tEnter your filing status: ");
    scanf("%d", &filingStatus);

    printf("\tEnter your taxable income: ");
    scanf("%1f", &taxableIncome);


    if (filingStatus == 0) {
        // Single filer//
        if (taxableIncome <= SINGLE_LIMIT) {
            taxAmount = SINGLE_RATE1 * taxableIncome;
        } else if (taxableIncome <= 28000) {
            taxAmount = SINGLE_RATE1 * SINGLE_LIMIT + SINGLE_RATE2 * (taxableIncome - SINGLE_LIMIT);
        } else if (taxableIncome <= 68000) {
            taxAmount = SINGLE_RATE1 * SINGLE_LIMIT + SINGLE_RATE2 * (28000 - SINGLE_LIMIT) + SINGLE_RATE3 * (taxableIncome - 28000);
        } else if (taxableIncome <= 140000) {
            taxAmount = SINGLE_RATE1 * SINGLE_LIMIT + SINGLE_RATE2 * (28000 - SINGLE_LIMIT) + SINGLE_RATE3 * (68000 - 28000) + SINGLE_RATE4 * (taxableIncome - 68000);
        } else {
            printf("Invalid taxable income for single filers!\n");
            return 1;
        }
    } else if (filingStatus == 1) {
        // Married filing jointly//
        if (taxableIncome <= JOINT_LIMIT) {
            taxAmount = JOINT_RATE1 * taxableIncome;
        } else if (taxableIncome <= 47000) {
            taxAmount = JOINT_RATE1 * JOINT_LIMIT + JOINT_RATE2 * (taxableIncome - JOINT_LIMIT);
        } else if (taxableIncome <= 112000) {
            taxAmount = JOINT_RATE1 * JOINT_LIMIT + JOINT_RATE2 * (47000 - JOINT_LIMIT) + JOINT_RATE3 * (taxableIncome - 47000);
        } else if (taxableIncome <= 170000) {
            taxAmount = JOINT_RATE1 * JOINT_LIMIT + JOINT_RATE2 * (47000 - JOINT_LIMIT) + JOINT_RATE3 * (112000 - 47000) + JOINT_RATE4 * (taxableIncome - 112000);
        } else {
            printf("Invalid taxable income for married filing jointly!\n");
            return 1;
        }
    } else if (filingStatus == 2) {
        // Married filing separately//
        if (taxableIncome <= SEPARATE_LIMIT) {
            taxAmount = JOINT_RATE1 * taxableIncome;
        } else if (taxableIncome <= 47000) {
            taxAmount = JOINT_RATE1 * SEPARATE_LIMIT + JOINT_RATE2 * (taxableIncome - SEPARATE_LIMIT);
        } else if (taxableIncome <= 112000) {
            taxAmount = JOINT_RATE1 * SEPARATE_LIMIT + JOINT_RATE2 * (47000 - SEPARATE_LIMIT) + JOINT_RATE3 * (taxableIncome - 47000);
        } else if (taxableIncome <= 170000) {
            taxAmount = JOINT_RATE1 * SEPARATE_LIMIT + JOINT_RATE2 * (47000 - SEPARATE_LIMIT) + JOINT_RATE3 * (112000 - 47000) + JOINT_RATE4 * (taxableIncome - 112000);
        } else {
            printf("Invalid taxable income for married filing jointly!\n");
            return 1;
        }
    }
    printf("\n\tYour tax amount is: $%f\n", taxAmount);
}
