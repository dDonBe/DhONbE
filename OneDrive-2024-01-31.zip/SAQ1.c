#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>

COORD cord = { 0, 0 };
void gotoxy(int x, int y)
{
    cord.X = x;
    cord.Y = y;
    SetConsoleCursorPosition(
        GetStdHandle(STD_OUTPUT_HANDLE),
        cord);
}

 //options


 //header footer

void headerfooter()
{

    gotoxy(5,2);
    printf("=======================================================");
    gotoxy(5,3);
    printf("|             MANUE SELECTION Version 1.0             |");
    gotoxy(5,4);
    printf("=======================================================");

    gotoxy(5,14);
    printf("=======================================================");
    gotoxy(5,15);
    printf("=========THANK YOU FOR USING THIS SOFTWARE!!!==========");
    gotoxy(5,16);
    printf("========Created by: Jake R. Pomperada, MEAD-IT=========");
    gotoxy(5,17);
    printf("=======================================================");

}


char mainManue()
{

    headerfooter();


    gotoxy(5,5);
    printf("|     List of Geometric Figures                       |");
    gotoxy(5,6);
    printf("|           1 -  CIRCLE                               |");
    gotoxy(5,7);
    printf("|           2 -  SQUARE                               |");
    gotoxy(5,8);
    printf("|           3 -  RECTANGLE                            |");
    gotoxy(5,9);
    printf("|           4 -  TRIANGLE                             |");
    gotoxy(5,10);
    printf("|           5 -  Exit                                 |");
    gotoxy(5,11);
    printf("=======================================================");

    gotoxy(7,12);
    printf("Select option :=>  ");
    return (getche());
}


 //options choosing

void main()
{
    char option;
    do
    {
        option = mainManue();
        switch(option)
        {
        case'1':
            circle();
            break;
        case'2':
            square();
            break;
        case'3':
            rectangle();
            break;
        case'4':
            triangle();
            break;
        case'5':case'E':
            gotoxy(26,12);
            printf("Hope you got it..%c",1);
            break;
        }
        getch();
    }
    while(option!='5'&&option!='E');

}
void circle()
{
    system("cls");

    int rad;
    float area;
    const float pi=3.14159;

    printf("Enter the radius of the circle: ");
    scanf("%d", &rad);

    area = pi * (rad *rad);

    printf("The area of the circle is: %.2f",area);

}
void square()
{
    system("cls");

    int width;
    float area, perimeter;

    printf("Enter the width of the square: ");
    scanf("%d", &width);

    area = width*width;
    perimeter = 4*width;

    printf("\nThe area of the square is: %.2f",area);
    printf("\nThe perimeter of the square is: %.2f",perimeter);
}
void rectangle()
{
    system("cls");

    int length, width;
    float area, perimeter;

    printf("Enter the side 1 width of the rectangle: ");
    scanf("%d", &width);
    printf("Enter the side 1 length of the rectangle: ");
    scanf("%d", &length);

    area = length*width;
    perimeter = 2*(width + length) ;

    printf("\nThe area of the rectangle is: %.2f",area);
    printf("\nThe perimeter of the rectangle is: %.2f",perimeter);
}
void triangle()
{
    system("cls");

    int side1, side2, base, height;
    float area, perimeter;

    printf("Enter the side a length of the triangle: ");
    scanf("%d", &side1);
    printf("Enter the side b length of the triangle: ");
    scanf("%d", &side2);
    printf("Enter the base length of the triangle: ");
    scanf("%d", &base);
    printf("Enter the height of the triangle: ");
    scanf("%d", &height);

    area = (base*height)/2 ;
    perimeter = side1+side2+base ;

    printf("\nThe area of the rectangle is: %.2f",area);
    printf("\nThe perimeter of the rectangle is: %.2f",perimeter);
}



