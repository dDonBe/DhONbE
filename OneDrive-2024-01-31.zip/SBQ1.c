#include<stdio.h>
#include<conio.h>

main()
{
    int stid;
    float as1,as2,exam,tuto;
    float fmark;
    char grade;

    printf("Enter the student ID: ");
    scanf("%d",&stid);
    printf("Enter the raw marks for the tutorial: ");
    scanf("%f",&tuto);
    printf("Enter the raw marks for the assignment 1: ");
    scanf("%f",&as1);
    printf("Enter the raw marks for the assignment 2: ");
    scanf("%f",&as2);
    printf("Enter the raw examination marks: ");
    scanf("%f",&exam);

    if(exam >75)
    {
        printf("Exam marks is below 75");
    }
    else
    {
        fmark=tuto/100*10+as1/100*10+as2/100*10+exam;
        printf("Final Marks for student %d : %2.f\n",stid,fmark);

        if (fmark<60)

            printf("F");

        else if ((fmark<70)&&(fmark>61))
        {
            printf("D");
        }
        else if ((fmark<80)&&(fmark>71))
        {
            printf("C");
        }
        else if ((fmark<90)&&(fmark>81))
        {
            printf("B");
        }
        else ((fmark<=100)&&(fmark>91));
        {
            printf("A");
        }

        printf("The grade for student %d : ",stid);
    }






}
