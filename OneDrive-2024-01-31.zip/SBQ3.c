#include <stdio.h>
#include <conio.h>
#include <string.h>


struct harddisk
{
    char model[100],colour;
    float price;
    int capacity;
};

int main()
{
    struct harddisk disks[10];


    for (int i = 0; i < 9; i++) {
        sprintf(disks[i].model, "Model %d", i);
        disks[i].colour = 'R';
        disks[i].price = 98.76;
        disks[i].capacity = 2;
    }


    printf("Enter details for the last hard disk:\n");
    printf("Model: ");
    scanf("%s", disks[9].model);

    printf("Colour: ");
    scanf(" %c", &disks[9].colour);

    printf("Price: ");
    scanf("%f", &disks[9].price);

    printf("Capacity: ");
    scanf("%d", &disks[9].capacity);


    FILE *file = fopen("harddisks.stg", "w");
    if (file == NULL) {
        printf("Error opening file.");
        return 1;
    }

    fwrite(disks, sizeof(struct harddisk), 10, file);
    fclose(file);


    struct harddisk readDisks[10];

    file = fopen("harddisks.stg", "r");
    if (file == NULL) {
        printf("Error opening file.");
        return 1;
    }

    fread(readDisks, sizeof(struct harddisk), 10, file);
    fclose(file);





    printf("\n\n\tHard Disk Details:\n");
    printf("---------------------------------");
    printf("\n|\tModel: %s\n", readDisks[9].model);
    printf("---------------------------------");
    printf("\n|\tColour: %c\n", readDisks[9].colour);
    printf("---------------------------------");
    printf("\n|\tPrice: $%.2f\n", readDisks[9].price);
    printf("---------------------------------");
    printf("\n|\tCapacity: %dTB\n", readDisks[9].capacity);
    printf("---------------------------------");

    return 0;
    getches();
}
