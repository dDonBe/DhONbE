#include <stdio.h>
#include <conio.h>

#define NUM_EMPS 10

int main() {
    int sal[NUM_EMPS], ttS = 0, avS, aAv = 0,  hhS = 0;

    // Input salaries for each employee//
    printf("Enter the salaries for %d employees:\n", NUM_EMPS);
    for (int i = 0; i < NUM_EMPS; i++) {
        printf("Salary %d: $", i + 1);
        scanf("%d", &sal[i]);
        ttS += sal[i];

        if (sal[i] > hhS) {
            hhS = sal[i];
        }
    }

    // Calculate average salary//
    avS = ttS / NUM_EMPS;

    // Count employees whose salary is above average//
    for (int i = 0; i < NUM_EMPS; i++) {
        if (sal[i] > avS) {
            aAv++;
        }
    }

    // Display results//
    printf("\n\nTotal salary for the month: %d", ttS);
    printf("\nNumber of employees whose salary is above %d average: %d",avS ,aAv);
    printf("\nHighest salary paid: %d\n", hhS);

    return 0;
    getch();
}

