#include<stdio.h>
#include<conio.h>
#include<string.h>


main()
{
  int lintg, sop = 0, poe = 1, num = 2;

  printf("Enter the last integer: ");
  scanf("%d",&lintg);

  do
  {
      sop = sop +num * (num + 1);

      if (num %2 == 0)
      {
          poe = poe *num;
      }
      num++;
  }
  while (num<=lintg);

  printf("Sum of products: %d",sop);
  printf("\nProduct of even numbers: %d",poe);

  getch();
}
